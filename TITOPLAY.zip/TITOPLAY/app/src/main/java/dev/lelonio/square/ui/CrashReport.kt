package dev.lelonio.square.ui

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import java.io.File

/**
 * A way to learn why the app went away.
 *
 * Writes the stack of any uncaught exception to a file, and on the next start
 * shows it, along with the reason Android gives for the last time the process
 * ended (crash, native crash, out of memory, not responding...). The text can
 * be copied and sent. Nothing leaves the phone by itself.
 */
object CrashReport {
    private const val FILE = "last_crash.txt"
    private const val PREFS = "crash_report"
    private const val KEY_SEEN = "seen_exit_ts"

    fun install(activity: Activity) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                File(activity.applicationContext.filesDir, FILE)
                    .writeText("Thread: ${thread.name}\n" + error.stackTraceToString())
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun showIfAny(activity: Activity) {
        val sb = StringBuilder()
        var wantLog = false
        val file = File(activity.filesDir, FILE)
        if (file.exists()) {
            sb.append("Crash:\n").append(file.readText().take(6000)).append('\n')
            file.delete()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching {
                val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val seen = prefs.getLong(KEY_SEEN, 0L)
                val am = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val last = am.getHistoricalProcessExitReasons(activity.packageName, 0, 1).firstOrNull()
                if (last != null && last.timestamp > seen) {
                    prefs.edit().putLong(KEY_SEEN, last.timestamp).apply()
                    // Only a real crash or a hang. Being swiped away, low
                    // memory or the system tidying up are not worth a dialog.
                    val abnormal = when (last.reason) {
                        android.app.ApplicationExitInfo.REASON_CRASH,
                        android.app.ApplicationExitInfo.REASON_CRASH_NATIVE,
                        android.app.ApplicationExitInfo.REASON_ANR -> true
                        else -> false
                    }
                    if (abnormal) {
                        sb.append("Last exit: reason=").append(last.reason)
                            .append(" status=").append(last.status)
                            .append(" description=").append(last.description)
                            .append(" importance=").append(last.importance)
                            .append(" pss=").append(last.pss).append("KB")
                            .append(" rss=").append(last.rss).append("KB\n")
                        wantLog = true
                        // For a native crash or an ANR the system keeps a trace.
                        runCatching {
                            last.traceInputStream?.bufferedReader()?.use {
                                sb.append(it.readText().take(4000))
                            }
                        }
                    }
                }
            }
        }
        if (sb.isEmpty()) return
        if (wantLog) {
            // The app may read its own log. The crash's own line (which
            // thread, which address) and what was happening just before it.
            Thread {
                val log = runCatching {
                    val proc = ProcessBuilder("logcat", "-d", "-v", "threadtime", "-t", "4000")
                        .redirectErrorStream(true).start()
                    val lines = proc.inputStream.bufferedReader().readLines()
                    proc.destroy()
                    val at = lines.indexOfLast { "Fatal signal" in it || "SIGSEGV" in it }
                    if (at >= 0) lines.subList((at - 45).coerceAtLeast(0), (at + 8).coerceAtMost(lines.size))
                    else lines.takeLast(25)
                }.getOrNull().orEmpty().joinToString("\n").takeLast(6000)
                if (log.isNotBlank()) sb.append("\nLog:\n").append(log)
                show(activity, sb.toString())
            }.start()
        } else {
            show(activity, sb.toString())
        }
    }

    private fun show(activity: Activity, text: String) {
        activity.window.decorView.post {
            runCatching {
                AlertDialog.Builder(activity)
                    .setTitle("App ended unexpectedly")
                    .setMessage(text)
                    .setPositiveButton("Copy") { _, _ ->
                        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("TITOPLAY crash", text))
                    }
                    .setNegativeButton("Close", null)
                    .show()
            }
        }
    }
}
